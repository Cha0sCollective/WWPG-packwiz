14,650 node benchmark

Open this save from Singleplayer in the WWPG 0.2.2-beta.2 test pack.
Minecraft 1.21.1, NeoForge 21.1.248, Java 21; PG native engine, 16 substeps.
Use an 8 GiB maximum heap; leave sufficient memory for the operating system.
Creative spawn: 1038, 64, 1038. Loading this large grid can take several minutes.

This is the nominal 10,000-tier mixed benchmark: 14,650 actual electrical nodes,
20,637 connections, 1,050 stateful devices and 50 factories across 953 chunks.
Native wires, panels, boards and stored state are retained. The original save
was generated with WWPG 0.2.2-dev.2; the test pack supplies beta.2.
An optional separate helper records timed trials; it is not required to inspect
the existing CEE and PG circuits. This pack does not run a timed trial automatically.
The large-network 20 TPS goal remains open. Inclusion is not capacity certification.
Keep a clean instance for comparisons; edits change the workload.
